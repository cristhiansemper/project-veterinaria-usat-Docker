----------------------fn_lista_servicios()----------------------------------------
create or replace function fn_lista_servicios()
returns table(id_servicio int, descripcion varchar(50), precio numeric(5,2),
			  estado boolean, id_tipo_servicio_id integer, tipo_servicio_descripcion varchar(50))
as
$$
begin
return query
select ser.id_servicio, ser.descripcion, ser.precio,
		ser.estado, ser.id_tipo_servicio_id, ts.descripcion
from citas_servicio ser
inner join citas_tiposervicio ts on ser.id_tipo_servicio_id=ts.id_tipo_servicio;
end;
$$
language 'plpgsql';
---------------------fn_lista_mascotas()--------------------
create or replace function fn_lista_mascotas()
returns table(id_mascota int, nombre varchar(50), fechaNac date,
			  sexo int, fechaRegistro date, estado boolean,
			  id_cliente_id int, id_raza_id int, descripcion_raza varchar(50), 
			  nombre_cliente text,
			  id_usuario_id bigint,
			  documento varchar(8),
			  descr varchar(50),
			  tipomas int
			 ) 
as
$$
begin
return query
select ma.id_mascota , ma.nombre, ma.fecha_nacimiento, 
		ma.sexo,  ma.fecha_registro, ma.estado, 
		ma.id_cliente_id, ma.id_raza_id , ra.descripcion as descripcion_raza, 
		cc.nombre || ' '|| cc.apellido as nombre ,ma.id_usuario_id, cc.numero_documento,
		tm.descripcion, tm.id_tipo_mascota
from citas_mascota  ma 
inner join citas_raza ra on ma.id_raza_id = ra.id_raza
inner join gestion_cliente cc on cc.id_cliente=ma.id_cliente_id
inner join citas_tipomascota tm on tm.id_tipo_mascota=ra.id_tipo_mascota_id;
end;
$$
language 'plpgsql';