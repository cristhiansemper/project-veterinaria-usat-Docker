from django.contrib import admin
from apps.gestion.models import *
# Register your models here.
admin.site.register(TipoEmpleado)
admin.site.register(TipoDocumento)
admin.site.register(Usuario)
admin.site.register(Cliente)


